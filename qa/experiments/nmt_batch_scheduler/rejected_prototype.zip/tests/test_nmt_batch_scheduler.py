from dataclasses import replace
from types import SimpleNamespace
from threading import Event, Thread, current_thread

import pytest

from app.documents.pipeline import PipelineCapabilities, GIB, MIB
from app.engine.backends.m2m100_backend import M2M100Backend
from app.engine.errors import TranslationError, DeviceUnavailableError, TranslationCancelledError
from app.engine.runtime.nmt_batch_scheduler import BatchPlan, SemanticBatchScheduler, finish_segment
from app.engine.runtime.runtime_manager import RuntimeManager
from app.engine.types import TranslationRequest, InferenceOptions, PairKind, BackendOutput

OPTIONS = InferenceOptions('cuda', 'int8_float16', 8, 4, 768, 192, 512)


class Tokenizer:
    languages = {'zh', 'ru', 'en'}
    def encode(self, text): return text.split()
    def source_tokens(self, pieces, language): return [f'__{language}__', *pieces, '</s>']
    def decode(self, pieces): return ' '.join(pieces[1:])


class Backend(M2M100Backend):
    def __init__(self, native):
        self.models = SimpleNamespace(root='fixed-model')
        self._tokenizer = Tokenizer()
        self._translator = SimpleNamespace(translate_batch=native)
        self._record = SimpleNamespace(id='m2m100-fixed')
    def _load(self, options): pass
    def supports_pair(self, source, target): return source != target
    def shutdown(self): pass


class Fallback:
    def translate(self, request, *args): return BackendOutput('fallback:'+request.text, ('argos-fixed',))
    def shutdown(self): pass


def execute(texts, *, ceiling=8, native=None, options=None, cancelled=None, guard=None):
    calls=[];attempts=[];guards=[];owners=[]
    cancelled = cancelled or Event()
    def infer(source, **settings):
        calls.append((source,settings))
        if native: native(source)
        return [SimpleNamespace(hypotheses=[[settings['target_prefix'][i][0], *row[1:-1]]]) for i,row in enumerate(source)]
    runtime=RuntimeManager({'m2m100':Backend(infer),'argos':Fallback()},idle_timeout_seconds=0)
    scheduler=SemanticBatchScheduler(BatchPlan(ceiling),cancelled)
    def route(request, opts):
        for name in ('m2m100','argos'):
            if runtime.blocked_error(name,request,PairKind.DIRECT,opts):continue
            try:
                result=runtime.run(name,request,PairKind.DIRECT,opts,cancelled)
                attempts.append((request.text,name,'ok'))
                return result.text
            except (TranslationError,DeviceUnavailableError) as error:
                attempts.append((request.text,name,type(error).__name__))
    def callback(item):
        index,text=item
        try:
            request=TranslationRequest(text,'zh','ru')
            result=route(request,options[index] if options else OPTIONS)
            guards.append(index);owners.append(current_thread().name)
            if guard:result=guard(index,result,lambda t:route(replace(request,text=t),OPTIONS))
            return result
        finally:
            import sys
            finish_segment(sys.exc_info()[0] is not None)
    try:
        with runtime.keep_warm():result=list(scheduler.ordered(enumerate(texts),callback))
    finally:runtime.shutdown()
    return dict(result=result,calls=calls,attempts=attempts,guards=guards,metrics=dict(scheduler.metrics),owners=owners)


@pytest.mark.parametrize('ceiling',[1,2,4,8])
def test_exact_order_unicode_placeholders_ids_mixed_lengths(ceiling):
    texts=['中文 ZXQ0001QXZ 44 ± 5','A001 12.3 N·m','短','另外 一个 更长 内容','…','','42','转向 灯']
    before=execute(texts,ceiling=1)
    after=execute(texts,ceiling=ceiling)
    assert after['result']==before['result']
    assert after['attempts']==before['attempts']
    assert after['guards']==list(range(len(texts)))
    assert max(len(c[0]) for c in after['calls'])<=ceiling
    if ceiling>1:assert len(after['calls'])<len(before['calls'])


def test_incompatible_options_flush_and_near_input_limit_remains_original():
    texts=['中文','word '*191,'最后','beam','final']
    options=[OPTIONS,OPTIONS,OPTIONS,replace(OPTIONS,beam_size=2),OPTIONS]
    before=execute(texts,ceiling=1,options=options)
    after=execute(texts,options=options)
    assert after['result']==before['result']
    assert after['attempts']==before['attempts']
    assert [len(c[0]) for c in after['calls']]==[1]*5


def test_input_failure_replayed_per_owner_preserves_successful_neighbors():
    def failure(source):
        if any('bad' in row for row in source):raise TranslationError('input failed')
    before=execute(['好','bad','成功'],ceiling=1,native=failure)
    after=execute(['好','bad','成功'],native=failure)
    assert after['result']==before['result']
    assert after['attempts']==before['attempts']
    assert after['metrics']['batch_error_singleton_replay']==2


def test_device_failure_circuit_state_rechecked_after_first_owner():
    def failure(source):raise DeviceUnavailableError()
    before=execute(['一','二','三'],ceiling=1,native=failure)
    after=execute(['一','二','三'],native=failure)
    assert after['result']==before['result']
    assert after['attempts']==before['attempts']
    assert len(after['calls'])==2  # Batch error then first singleton; next owners observe breaker.


def test_guard_retry_is_serial_before_next_owner_commits():
    def guard(index,result,route):return route('retry') if index==0 else result
    before=execute(['一','二','三'],ceiling=1,guard=guard)
    after=execute(['一','二','三'],guard=guard)
    assert after['attempts']==before['attempts']
    assert after['result']==before['result']
    assert [len(c[0]) for c in after['calls']]==[3,1]


def test_cancel_before_dispatch_and_inside_native_clears_continuations():
    cancelled=Event();cancelled.set()
    with pytest.raises(TranslationCancelledError):execute(['中文'],cancelled=cancelled)
    cancelled.clear()
    with pytest.raises(TranslationCancelledError):
        execute(['一','二','三'],cancelled=cancelled,native=lambda source:cancelled.set())


def test_cancel_during_owner_preparation_wait():
    cancelled,entered,release=Event(),Event(),Event()
    def cancel():
        assert entered.wait(3)
        cancelled.set();release.set()
    canceller=Thread(target=cancel);canceller.start()
    scheduler=SemanticBatchScheduler(BatchPlan(8),cancelled)
    def callback(item):
        entered.set();assert release.wait(3)
        from app.engine.backends.base_backend import check_cancelled
        check_cancelled(cancelled)
    try:
        with pytest.raises(TranslationCancelledError):list(scheduler.ordered([1,2],callback))
    finally:canceller.join(3)
    assert all(task.future.done() for task in scheduler.pending)


def test_known_result_guard_barrier_cannot_run_before_previous_model_owner():
    from app.engine.runtime.nmt_batch_scheduler import serial_boundary, route_ready
    order=[]
    scheduler=SemanticBatchScheduler(BatchPlan(8),Event())
    runtime=SimpleNamespace(backends={'m2m100':SimpleNamespace(models=SimpleNamespace(root='fixed'))})
    def callback(item):
        if item==0:route_ready(runtime,'m2m100',TranslationRequest('一','zh','ru'),PairKind.DIRECT,OPTIONS)
        else:serial_boundary()
        order.append(('guard',item));finish_segment();return item
    assert list(scheduler.ordered([0,1,2],callback))==[(i,i) for i in range(3)]
    assert order==[('guard',i) for i in range(3)]


@pytest.mark.parametrize('cuda,free,pressure,expected',[
    (False,12*GIB,0,1),(True,12*GIB,0,8),(True,4608*MIB,0,2),
    (True,4864*MIB,0,4),(True,4300*MIB,0,1),(True,12*GIB,.8,2),(True,12*GIB,.9,1)])
def test_capability_ceiling_cpu_low_vram_pressure(cuda,free,pressure,expected):
    caps=PipelineCapabilities(16,8,32*GIB,20*GIB,cuda,12*GIB,free,768*MIB,2*GIB,pressure)
    assert BatchPlan.build(caps).max_sequences==expected


@pytest.mark.parametrize('depth',[1,2])
def test_document_contexts_and_single_semantic_owner_across_pipeline_depth(depth):
    from contextvars import ContextVar
    context=ContextVar('test-document',default=None)
    seen=[]
    for document in range(depth):
        token=context.set(document)
        scheduler=SemanticBatchScheduler(BatchPlan(8),Event(),document_sequence=document)
        def callback(item):
            seen.append((context.get(),item));finish_segment();return item
        assert list(scheduler.ordered(range(8),callback))==[(i,i) for i in range(8)]
        context.reset(token)
    assert seen==[(d,i) for d in range(depth) for i in range(8)]
