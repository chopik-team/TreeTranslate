"""Bounded intra-document continuations; exactly one semantic owner is active.

Workers are suspended stacks, not concurrent semantic owners. Preparation stops
BEFORE the router's circuit check. Only the first canonical owner runs native
inference; later owners recheck the circuit and retain the original fallback.
The broker touches tokenizer/model data only, never Knowledge or document state.
"""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from contextvars import ContextVar, copy_context
from dataclasses import dataclass
from queue import Queue, Empty
from threading import Event

from app.engine.backends.base_backend import check_cancelled
from app.engine.errors import TranslationCancelledError

_task = ContextVar('nmt_continuation', default=None)
MIB = 1024**2


@dataclass(frozen=True, slots=True)
class BatchPlan:
    max_sequences: int
    max_tokens: int = 256
    short_tokens: int = 32
    max_prepared_bytes: int = 1024*1024

    @classmethod
    def build(cls, capabilities):
        c=capabilities
        available=max(0,min(c.vram_total,c.vram_free)-max(512*MIB,c.vram_total//8)
                      -c.nmt_resident_bytes-c.ocr_resident_bytes)
        count=8 if available>=1024*MIB else 4 if available>=512*MIB else 2 if available>=256*MIB else 1
        if not c.cuda or c.memory_pressure>=.85 or c.ram_available<2*1024**3:count=1
        elif c.memory_pressure>=.70:count=min(count,2)
        return cls(count)


@dataclass(frozen=True, slots=True)
class ModelEnvelope:
    request_id: str
    document_sequence_id: int
    segment_sequence_id: int
    backend: str
    model_identity: str
    device: str
    source_language: str
    target_language: str
    prepared_source: str
    options: object
    fallback_identity: object

    @property
    def compatibility(self):
        return (self.backend,self.model_identity,self.source_language,self.target_language,self.options,self.fallback_identity)


def discarded():
    task=_task.get()
    return bool(task and task.discard)


def route_ready(runtime,backend,request,kind,options):
    task=_task.get()
    if task is None or task.phase!='prepare':return
    envelope=ModelEnvelope(request.request_id,task.owner.document_sequence,task.sequence,backend,
        str(getattr(runtime.backends[backend],'models',None).root) if getattr(runtime.backends[backend],'models',None) else backend,
        options.device,request.source_language,request.target_language,request.text,options,kind)
    task.pause('model',envelope)


def finish_segment(error=False):
    task=_task.get()
    if task is not None and task.phase=='prepare':task.pause('failed' if error else 'finished',None)


def serial_boundary():
    """A result-dependent guard must commit in canonical semantic order."""
    task=_task.get()
    if task is not None and task.phase=='prepare':task.pause('barrier',None)


def prepared_encode(request,options,encode):
    task=_task.get()
    if task and task.encoding and task.encoding[0]==(request.text,request.source_language,request.target_language,options):
        cache=task.encoding[1]
        return lambda text: list(cache[text]) if text in cache else encode(text)
    return encode


def native_infer(backend,request,options,source,settings,call,cancelled):
    task=_task.get()
    if task is None:return call(source,**settings)
    identity=(options,tuple(tuple(s) for s in source),settings)
    if task.cached is not None:
        expected,result=task.cached;task.cached=None
        if expected==identity:
            task.native_seen=True;return result
    if task.native_seen or len(source)!=1 or len(source[0])>task.owner.plan.short_tokens:
        task.native_seen=True;return call(source,**settings)
    task.native_seen=True
    return task.owner.dispatch(task,backend,request,options,source,settings,call,cancelled)


class _Capture(BaseException):
    def __init__(self,batches):self.batches=batches


class _Continuation:
    def __init__(self,owner,sequence,item,callback):
        self.owner,self.sequence,self.item,self.callback=owner,sequence,item,callback
        self.phase='prepare';self.discard=False;self.native_seen=False
        self.encoding=None;self.cached=None;self.envelope=None;self.saved=None
        self.gate=Event();self.messages=Queue(maxsize=1);context=copy_context()
        self.context=context
        self.future=None

    def run(self):
        token=_task.set(self)
        try:
            self.gate.wait();self.gate.clear()
            if self.discard:raise TranslationCancelledError()
            result=self.callback(self.item)
            self.messages.put(('done',result,None))
        except BaseException as error:self.messages.put(('done',None,error))
        finally:_task.reset(token)

    def pause(self,kind,value):
        if kind=='model':self.envelope=value
        self.saved=self.owner.capture()
        self.messages.put((kind,value,None))
        self.gate.wait();self.gate.clear()
        if self.discard:raise TranslationCancelledError()


class SemanticBatchScheduler:
    def __init__(self,plan,cancelled,*,document_sequence=0,capture=lambda:None,activate=lambda state:None):
        self.plan,self.cancelled=plan,cancelled
        self.document_sequence=document_sequence;self.capture,self.activate=capture,activate
        self.pending=[];self.metrics=Counter()

    def advance(self,task,*,commit=False):
        check_cancelled(self.cancelled)
        if commit:task.phase='commit'
        if task.saved is not None:self.activate(task.saved)
        task.gate.set()
        while True:
            try:return task.messages.get(timeout=.1)
            except Empty:check_cancelled(self.cancelled)

    def ordered(self,items,callback):
        if self.plan.max_sequences==1:
            for item in items:yield item,callback(item)
            return
        iterator=iter(enumerate(items));exhausted=False
        pool=ThreadPoolExecutor(max_workers=self.plan.max_sequences,thread_name_prefix='nmt-semantic-continuation')
        try:
            while not exhausted:
                self.pending=[]
                for _ in range(self.plan.max_sequences):
                    try:sequence,item=next(iterator)
                    except StopIteration:exhausted=True;break
                    task=_Continuation(self,sequence,item,callback);self.pending.append(task)
                    task.future=pool.submit(task.context.run,task.run)
                    kind,value,error=self.advance(task)
                    if kind=='done':
                        task.result=value;task.error=error
                        break  # A failed prefix is an admission/dependency barrier.
                    if kind=='model':
                        self.metrics['ready_model_requests']+=1
                        if value.backend!='m2m100':break  # Argos/language/fallback remains serial.
                    if kind in {'failed','barrier'}:break
                for task in self.pending:
                    if hasattr(task,'error'):
                        if task.error:raise task.error
                        result=task.result
                    else:
                        kind,result,error=self.advance(task,commit=True)
                        assert kind=='done','Committed semantic continuation cannot yield another frontier'
                        if error:raise error
                    task.future.result()
                    yield task.item,result
        finally:
            for task in self.pending:
                if not task.future.done():
                    task.discard=True;task.phase='commit'
                    if task.saved is not None:self.activate(task.saved)
                    task.gate.set();task.future.result()
            pool.shutdown(wait=True)

    def dispatch(self,current,backend,request,options,source,settings,call,cancelled):
        from app.engine.backends.text_segments import translate_segments
        check_cancelled(cancelled)
        envelope=current.envelope
        if (envelope.backend!=backend.name or envelope.options!=options
                or envelope.prepared_source!=request.text
                or (envelope.source_language,envelope.target_language)!=(request.source_language,request.target_language)):
            return call(source,**settings)  # Original device/fallback advanced after circuit check.
        group=[current];sources=list(source);tokens=len(source[0]);prepared_bytes=sum(len(t.encode('utf8'))+128 for t in source[0])
        for task in self.pending:
            envelope=task.envelope
            if task.sequence<=current.sequence or task.cached is not None or envelope is None:continue
            if envelope.compatibility!=current.envelope.compatibility:break
            if len(group)>=self.plan.max_sequences:break
            encoded={}
            def encode(text):
                pieces=backend._tokenizer.encode(text);encoded[text]=tuple(pieces);return pieces
            def capture(batches):raise _Capture(batches)
            try:
                translate_segments(envelope.prepared_source,envelope.target_language,encode,lambda x:'',capture,options,cancelled)
            except _Capture as captured:pieces=captured.batches
            except TranslationCancelledError:raise
            except Exception:break  # A neighbour's encoder error belongs to its own serial path.
            else:break
            task.encoding=((envelope.prepared_source,envelope.source_language,envelope.target_language,options),encoded)
            if len(pieces)!=1:break
            try:native=backend._tokenizer.source_tokens(pieces[0],envelope.source_language)
            except Exception:break
            size=sum(len(t.encode('utf8'))+128 for t in native)
            if len(native)>self.plan.short_tokens or tokens+len(native)>min(self.plan.max_tokens,options.batch_tokens):break
            if prepared_bytes+size>self.plan.max_prepared_bytes:break
            group.append(task);sources.append(native);tokens+=len(native);prepared_bytes+=size
        if len(group)==1:return call(source,**settings)
        merged=dict(settings,target_prefix=[list(settings['target_prefix'][0]) for _ in group])
        self.metrics['physical_batch_calls']+=1;self.metrics['batched_sequences']+=len(group)
        self.metrics['prepared_bytes_high_water']=max(self.metrics['prepared_bytes_high_water'],prepared_bytes)
        try:
            results=call(sources,**merged)
            if len(results)!=len(group):raise RuntimeError('Native batch result cardinality mismatch')
        except Exception:
            check_cancelled(cancelled)
            self.metrics['batch_error_singleton_replay']+=1
            # Only the first canonical item is replayed now. Others re-enter the
            # ORIGINAL circuit/device/fallback path after this owner's outcome.
            return call(source,**settings)
        check_cancelled(cancelled)
        for index,task in enumerate(group[1:],1):
            single=[sources[index]]
            task.cached=((options,tuple(tuple(s) for s in single),settings),[results[index]])
        return [results[0]]


def for_document(engine,cancelled,**kwargs):
    from app.engine.runtime.runtime_manager import RuntimeManager
    from app.engine.backends.m2m100_backend import M2M100Backend
    runtime=getattr(engine,'runtime',None)
    if not isinstance(runtime,RuntimeManager) or not isinstance(runtime.backends.get('m2m100'),M2M100Backend):return None
    from app.documents.pipeline import PipelineCapabilities
    return SemanticBatchScheduler(BatchPlan.build(PipelineCapabilities.detect()),cancelled,**kwargs)
